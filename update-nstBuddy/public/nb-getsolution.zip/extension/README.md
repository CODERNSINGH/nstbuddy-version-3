# NewtonSchool Get Solution Extension

This browser extension injects a `Get Solution` button into the NewtonSchool code editor header.

## What it does
- Detects the question title from the page.
- Adds a `Get Solution` button near the editor action buttons.
- Opens the top search result for the question via Google "I’m Feeling Lucky" search.

## Install
1. Open Chrome and go to `chrome://extensions/`.
2. Enable Developer mode.
3. Click `Load unpacked` and choose this `extension/` folder.

## Notes
- The extension targets pages under `https://my.newtonschool.co/*`.
- The button is injected dynamically and updates when the page DOM changes.
