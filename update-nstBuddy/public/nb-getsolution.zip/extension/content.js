const EXTENSION_BUTTON_ID = 'newtonschool-get-solution-button';
const QUESTION_SELECTOR = 'span.sc-3ef8580b-7.frXhPl';
const TOOLBAR_SELECTOR = 'div.sc-ba187bc5-0.GWnGo';
const BUTTON_WRAPPER_SELECTOR = 'div.sc-ba187bc5-3.cuxIBZ';
const BACKEND_API_BASE = 'https://update-nstbuddy.onrender.com/api';
const SOLUTION_ENDPOINT = `${BACKEND_API_BASE}/questions/solution`;

function createGetSolutionButton() {
  const button = document.createElement('button');
  button.id = EXTENSION_BUTTON_ID;
  button.type = 'button';
  button.textContent = 'Get Solution';
  button.disabled = true;
  button.style.cursor = 'not-allowed';
  button.style.display = 'flex';
  button.style.padding = '8px 20px';
  button.style.justifyContent = 'center';
  button.style.alignItems = 'center';
  button.style.gap = '4px';
  button.style.background = '#94a3b8';
  button.style.color = '#ffffff';
  button.style.border = 'none';
  button.style.borderRadius = '8px';
  button.style.fontWeight = '550';
  button.style.fontSize = '16px';
  button.style.lineHeight = '24px';
  button.style.letterSpacing = '0.4px';
  button.style.marginLeft = '0.5rem';
  button.style.whiteSpace = 'nowrap';
  button.style.width = 'fit-content';
  button.dataset.questionTitle = '';
  button.title = 'Searching for solution...';
  button.addEventListener('click', (event) => {
    event.stopPropagation();
    event.preventDefault();
    const solutionLink = button.dataset.solutionLink;
    if (solutionLink) {
      window.open(solutionLink, '_blank', 'noopener,noreferrer');
    }
  });
  return button;
}

function setButtonState(button, link) {
  if (link) {
    button.disabled = false;
    button.dataset.solutionLink = link;
    button.style.background = '#16a34a';
    button.style.cursor = 'pointer';
    button.title = 'Open the found solution link';
  } else {
    button.disabled = true;
    button.dataset.solutionLink = '';
    button.style.background = '#94a3b8';
    button.style.cursor = 'not-allowed';
    button.title = 'Solution not found yet';
  }
}

async function checkSolutionAvailability(button, questionTitle) {
  if (!questionTitle) {
    setButtonState(button, null);
    return;
  }

  try {
    const response = await fetch(`${SOLUTION_ENDPOINT}?questionName=${encodeURIComponent(questionTitle.trim())}`);
    if (!response.ok) {
      setButtonState(button, null);
      return;
    }

    const data = await response.json();
    if (data && data.success && data.found && data.question?.link) {
      setButtonState(button, data.question.link);
    } else {
      setButtonState(button, null);
    }
  } catch (error) {
    console.error('Solution lookup error:', error);
    setButtonState(button, null);
  }
}

function injectButtonIfNeeded() {
  const toolbar = document.querySelector(TOOLBAR_SELECTOR);
  if (!toolbar) {
    return;
  }

  const questionElement = document.querySelector(QUESTION_SELECTOR);
  const questionTitle = questionElement ? questionElement.textContent : '';

  let solutionButton = document.getElementById(EXTENSION_BUTTON_ID);
  if (solutionButton) {
    const existingTitle = solutionButton.dataset.questionTitle || '';
    if (existingTitle !== questionTitle) {
      solutionButton.dataset.questionTitle = questionTitle;
      checkSolutionAvailability(solutionButton, questionTitle);
    }
    return;
  }

  solutionButton = createGetSolutionButton();
  solutionButton.dataset.questionTitle = questionTitle;
  if (questionTitle) {
    checkSolutionAvailability(solutionButton, questionTitle);
  }

  const buttonWrapper = toolbar.querySelector(BUTTON_WRAPPER_SELECTOR) || toolbar;
  if (buttonWrapper) {
    buttonWrapper.appendChild(solutionButton);
  } else {
    toolbar.appendChild(solutionButton);
  }
}

function startObserver() {
  const observer = new MutationObserver(() => {
    injectButtonIfNeeded();
  });

  observer.observe(document.body, { childList: true, subtree: true });
  injectButtonIfNeeded();
}

startObserver();
